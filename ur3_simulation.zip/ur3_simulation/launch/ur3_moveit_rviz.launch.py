from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription, OpaqueFunction
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration
from launch_ros.substitutions import FindPackageShare
from launch_ros.actions import Node


def launch_setup(context, *args, **kwargs):
    # Get launch configurations
    ur_type = LaunchConfiguration("ur_type")
    safety_limits = LaunchConfiguration("safety_limits")
    runtime_config_package = LaunchConfiguration("runtime_config_package")
    controllers_file = LaunchConfiguration("controllers_file")
    description_package = LaunchConfiguration("description_package")
    description_file = LaunchConfiguration("description_file")
    moveit_config_package = LaunchConfiguration("moveit_config_package")
    moveit_config_file = LaunchConfiguration("moveit_config_file")
    prefix = LaunchConfiguration("prefix")

    # UR Control (Gazebo, controllers, etc.)
    ur_control_launch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            [FindPackageShare("ur_simulation_gazebo"), "/launch", "/ur_sim_control.launch.py"]
        ),
        launch_arguments={
            "ur_type": ur_type,
            "safety_limits": safety_limits,
            "runtime_config_package": runtime_config_package,
            "controllers_file": controllers_file,
            "description_package": description_package,
            "description_file": description_file,
            "prefix": prefix,
            "launch_rviz": "false",
        }.items()
    )

    # MoveIt
    ur_moveit_launch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            [FindPackageShare("ur_moveit_config"), "/launch", "/ur_moveit.launch.py"]
        ),
        launch_arguments={
            "ur_type": ur_type,
            "safety_limits": safety_limits,
            "description_package": description_package,
            "description_file": description_file,
            "moveit_config_package": moveit_config_package,
            "moveit_config_file": moveit_config_file,
            "prefix": prefix,
            "use_sim_time": "true",
            "launch_rviz": "true",
            "use_fake_hardware": "true",
        }.items()
    )

    # Custom node: spawn environment objects (table, whiteboard)
    spawn_assets_node = Node(
        package="ur3_simulation",
        executable="spawn_assets",
        name="spawn_assets_node",
        output="screen",
        parameters=[{"use_sim_time": True}]
    )


    return [
        ur_control_launch,
        ur_moveit_launch,
        spawn_assets_node,
    ]


def generate_launch_description():
    declared_arguments = []

    declared_arguments.append(
        DeclareLaunchArgument("ur_type", default_value="ur3e", description="UR robot type")
    )
    declared_arguments.append(
        DeclareLaunchArgument("safety_limits", default_value="true", description="Enable safety limits")
    )
    declared_arguments.append(
        DeclareLaunchArgument("runtime_config_package", default_value="ur_simulation_gazebo")
    )
    declared_arguments.append(
        DeclareLaunchArgument("controllers_file", default_value="ur_controllers.yaml")
    )
    declared_arguments.append(
        DeclareLaunchArgument("description_package", default_value="ur_description")
    )
    declared_arguments.append(
        DeclareLaunchArgument("description_file", default_value="ur.urdf.xacro")
    )
    declared_arguments.append(
        DeclareLaunchArgument("moveit_config_package", default_value="ur_moveit_config")
    )
    declared_arguments.append(
        DeclareLaunchArgument("moveit_config_file", default_value="ur.srdf.xacro")
    )
    declared_arguments.append(
        DeclareLaunchArgument("prefix", default_value='""')
    )

    return LaunchDescription(declared_arguments + [OpaqueFunction(function=launch_setup)])
