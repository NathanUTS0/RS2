import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription, ExecuteProcess
from launch.launch_description_sources import PythonLaunchDescriptionSource
 
def generate_launch_description():
    ur_bringup_path = os.path.join(
        get_package_share_directory('ur_bringup'),
        'launch',
        'ur_control.launch.py'
    )
 
    ur_moveit_config_path = os.path.join(
        get_package_share_directory('ur_moveit_config'),
        'launch',
        'ur_moveit.launch.py'
    )
 
    ur_control_launch = ExecuteProcess(
        cmd=['ros2', 'launch', ur_bringup_path,
             'ur_type:=ur3e', 'robot_ip:=192.168.0.192',
             'use_fake_hardware:=false', 'launch_rviz:=false'],
        output='screen'
    )
 
    ur_moveit_launch = ExecuteProcess(
        cmd=['ros2', 'launch', ur_moveit_config_path, 'ur_type:=ur3e'],
        output='screen'
    )
 
    return LaunchDescription([
        ur_control_launch,
        ur_moveit_launch,
    ])