#include <iostream>
#include <chrono>
#include <string>
#include <filesystem> // For directory and file operations

// RealSense headers
#include <librealsense2/rs.hpp>

// OpenCV headers
#include <opencv2/opencv.hpp>

// ROS 2 + OpenCV bridge 
#include "rclcpp/rclcpp.hpp"
#include "sensor_msgs/msg/image.hpp"
#include "cv_bridge/cv_bridge.h"

using namespace cv;
namespace fs = std::filesystem;

// --- Configuration ---
const std::string REAL_SENSE_FILENAME = "realsense_latest.png";
const std::string SIM_CAMERA_FILENAME = "sim_camera_latest.png";
std::string screenshot_directory = "."; // Default to current directory

// Function to set the screenshot directory
void set_screenshot_directory(const std::string& dir) {
    screenshot_directory = dir;
    fs::create_directories(screenshot_directory); // Create directory if it doesn't exist
    std::cout << "Screenshot directory set to: " << screenshot_directory << std::endl;
}

bool capture_and_save_image(const Mat& image, const std::string& filename_base) {
    std::string full_filename = fs::path(screenshot_directory) / filename_base;
    if (fs::exists(full_filename)) {
        if (!fs::remove(full_filename)) {
            std::cerr << "Error deleting previous screenshot: " << full_filename << std::endl;
            return false;
        }
    }
    imwrite(full_filename, image);
    std::cout << "Screenshot saved as: " << full_filename << std::endl;
    return true;
}

bool try_realsense_capture() {
    try {
        rs2::pipeline pipeline;
        rs2::config config;
        config.enable_stream(RS2_STREAM_COLOR, 640, 480, RS2_FORMAT_BGR8, 30);

        pipeline.start(config);

        std::cout << "Checking RealSense camera..." << std::endl;
        auto start_time = std::chrono::steady_clock::now();
        rs2::frameset frames;
        while (true) {
            frames = pipeline.wait_for_frames(100); // Check for frames every 100ms
            if (frames) break;
            auto now = std::chrono::steady_clock::now();
            auto duration = std::chrono::duration_cast<std::chrono::seconds>(now - start_time);
            if (duration.count() >= 1) {
                std::cout << "No RealSense frame received within 1 second." << std::endl;
                pipeline.stop();
                return false;
            }
        }

        rs2::video_frame color_frame = frames.get_color_frame();

        if (!color_frame) {
            std::cerr << "RealSense color frame is empty." << std::endl;
            pipeline.stop();
            return false;
        }

        Mat color_mat(Size(color_frame.get_width(), color_frame.get_height()), CV_8UC3,
                      (void*)color_frame.get_data(), Mat::AUTO_STEP);
        Mat saved_image = color_mat.clone();

        imshow("RealSense RGB", saved_image);
        waitKey(1);

        capture_and_save_image(saved_image, REAL_SENSE_FILENAME);

        pipeline.stop();
        return true;

    } catch (const rs2::error &e) {
        std::cerr << "[RealSense] " << e.what() << std::endl;
    } catch (const std::exception &e) {
        std::cerr << "[Exception] " << e.what() << std::endl;
    }
    return false;
}

class SimImageCaptureNode : public rclcpp::Node {
public:
    SimImageCaptureNode() : Node("sim_image_capture_node") {
        std::cout << "Waiting for simulated image on /virtual_camera/image_raw..." << std::endl;
        sub_ = this->create_subscription<sensor_msgs::msg::Image>(
            "/virtual_camera/image_raw", 10,
            std::bind(&SimImageCaptureNode::image_callback, this, std::placeholders::_1)
        );
    }

private:
    void image_callback(const sensor_msgs::msg::Image::SharedPtr msg) {
        auto cv_ptr = cv_bridge::toCvCopy(msg, sensor_msgs::image_encodings::BGR8);
        Mat image = cv_ptr->image;

        imshow("Simulated Camera", image);
        waitKey(1);

        capture_and_save_image(image, SIM_CAMERA_FILENAME);

        rclcpp::shutdown();
    }

    rclcpp::Subscription<sensor_msgs::msg::Image>::SharedPtr sub_;
};

int main(int argc, char** argv) {
    rclcpp::init(argc, argv);

    // Check for a command-line argument for the directory
    if (argc > 1) {
        set_screenshot_directory(argv[1]);
    } else {
        std::cout << "Using default screenshot directory: " << screenshot_directory << std::endl;
    }

    if (try_realsense_capture()) {
        rclcpp::shutdown();
        return EXIT_SUCCESS;
    }

    std::cout << "Falling back to simulated camera via ROS..." << std::endl;
    rclcpp::spin(std::make_shared<SimImageCaptureNode>());
    rclcpp::shutdown();

    return EXIT_SUCCESS;
}