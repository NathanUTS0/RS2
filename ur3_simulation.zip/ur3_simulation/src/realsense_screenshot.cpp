#include <iostream>
#include <librealsense2/rs.hpp>
#include <opencv2/opencv.hpp>
#include <chrono>

using namespace cv;

int main() {
    // Create a RealSense pipeline
    rs2::pipeline pipeline;

    // Create a configuration for the pipeline
    rs2::config config;

    // Enable the color stream
    config.enable_stream(RS2_STREAM_COLOR, 640, 480, RS2_FORMAT_BGR8, 30);


    try {
        // Start the pipeline
        pipeline.start(config);

        std::cout << "Warming up camera..." << std::endl;
        for (int i = 0; i < 30; ++i) pipeline.wait_for_frames();

        std::cout << "Capturing a frame..." << std::endl;

        // Wait for a coherent frame set
        rs2::frameset frames = pipeline.wait_for_frames();

        // Get the color frame
        rs2::video_frame color_frame = frames.get_color_frame();

        if (color_frame) {
            // Create OpenCV Mat object from the color frame data
            Mat color_mat(Size(color_frame.get_width(), color_frame.get_height()), CV_8UC3,
                          (void*)color_frame.get_data(), Mat::AUTO_STEP);
            Mat saved_image = color_mat.clone(); // Clone to keep it after pipeline stop

            // Display the captured image
            imshow("RealSense RGB Screenshot", saved_image);
            waitKey(0); // Wait until a key is pressed

            // Save the image to a file
            auto now = std::chrono::system_clock::now();
            auto now_ms = std::chrono::time_point_cast<std::chrono::milliseconds>(now);
            auto value = now_ms.time_since_epoch().count();
            std::string filename = "realsense_screenshot_" + std::to_string(value) + ".png";
            imwrite(filename, saved_image);
            std::cout << "Screenshot saved as: " << filename << std::endl;
        } else {
            std::cerr << "Error: Could not retrieve color frame." << std::endl;
        }

        // Stop the pipeline
        pipeline.stop();

    } catch (const rs2::error &e) {
        std::cerr << "RealSense error calling " << e.get_failed_function()
                  << "(" << e.get_failed_args() << "):\n  " << e.what() << std::endl;
        return EXIT_FAILURE;
    } catch (const std::exception &e) {
        std::cerr << e.what() << std::endl;
        return EXIT_FAILURE;
    }

    return EXIT_SUCCESS;
}
