#include <rclcpp/rclcpp.hpp>
#include <moveit/move_group_interface/move_group_interface.h>
#include <geometry_msgs/msg/pose.hpp>
#include <tf2_geometry_msgs/tf2_geometry_msgs.hpp>

int main(int argc, char **argv) { 
    rclcpp::init(argc, argv);
    auto const node = std::make_shared<rclcpp::Node>("ur3_moveit_control");

    auto move_group_interface = std::make_shared<moveit::planning_interface::MoveGroupInterface>(node, "ur3_arm"); // Replace "ur3_arm" with your planning group name

    // Set the start state
    geometry_msgs::msg::Pose start_pose;
    start_pose.orientation.w = 1.0; // Default orientation
    start_pose.position.x = 0.3;     // Set your desired start position
    start_pose.position.y = 0.2;
    start_pose.position.z = 0.4;
    move_group_interface->setPoseTarget(start_pose);
    move_group_interface->setStartStateToCurrentState();

    // Plan and execute the start pose
    moveit::planning_interface::MoveGroupInterface::Plan start_plan;
    bool start_success = (move_group_interface->plan(start_plan) == moveit::core::MoveItErrorCode::SUCCESS);

    if (start_success) {
        move_group_interface->execute(start_plan);
    } else {
        RCLCPP_ERROR(node->get_logger(), "Failed to plan start pose");
    }

    // Set the goal pose
    geometry_msgs::msg::Pose target_pose;
    target_pose.orientation.w = 1.0;
    target_pose.position.x = 0.5;     // Set your desired goal position
    target_pose.position.y = -0.3;
    target_pose.position.z = 0.6;
    move_group_interface->setPoseTarget(target_pose);

    // Plan and execute the goal pose
    moveit::planning_interface::MoveGroupInterface::Plan goal_plan;
    bool goal_success = (move_group_interface->plan(goal_plan) == moveit::core::MoveItErrorCode::SUCCESS);

    if (goal_success) {
        move_group_interface->execute(goal_plan);
    } else {
        RCLCPP_ERROR(node->get_logger(), "Failed to plan goal pose");
    }

    rclcpp::shutdown();
    return 0;
}
