#include <QApplication>
#include <QPushButton>
#include <QVBoxLayout>
#include <QWidget>
#include <QProcess>
#include <QLabel>
#include <QTabWidget>
#include <QImage>
#include <QPixmap>
#include <QByteArray>
#include <iostream>
#include <QTimer>

class MainWindow : public QWidget {
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr) : QWidget(parent) {
        QVBoxLayout *layout = new QVBoxLayout(this);

        // Create a tab widget to hold multiple views (e.g., GUI and maze display)
        QTabWidget *tabWidget = new QTabWidget(this);
        layout->addWidget(tabWidget);

        // Tab 1: GUI with "Run Maze Solver" button
        QWidget *controlTab = new QWidget();
        QVBoxLayout *controlLayout = new QVBoxLayout(controlTab);
        QPushButton *mazeSolverButton = new QPushButton("Run Maze Solver", this);
        controlLayout->addWidget(mazeSolverButton);

        tabWidget->addTab(controlTab, "Control");

        // Tab 2: Maze Solver Display
        QWidget *mazeTab = new QWidget();
        QVBoxLayout *mazeLayout = new QVBoxLayout(mazeTab);
        mazeSolverLabel = new QLabel(this);
        mazeSolverLabel->setAlignment(Qt::AlignCenter);
        mazeSolverLabel->setMinimumSize(800, 600); // Set size for the display area
        mazeLayout->addWidget(mazeSolverLabel);

        tabWidget->addTab(mazeTab, "Maze Display");

        // Connect button to the solver logic
        connect(mazeSolverButton, &QPushButton::clicked, this, &MainWindow::runMazeSolver);

        // Set up the process and output reading
        process = new QProcess(this);
        connect(process, &QProcess::readyReadStandardOutput, this, &MainWindow::readMazeSolverOutput);
    }

private slots:
    void runMazeSolver() {
        // Launch the maze solver in a separate process
        process->start("bash", QStringList() << "-c" 
            << "source /opt/ros/humble/setup.bash && ros2 run ur3_simulation maze_solver");
    }

    void readMazeSolverOutput() {
        QByteArray output = process->readAllStandardOutput();
        QString outputString = QString(output);

        if (outputString.startsWith("IMAGE_DATA:")) {
            // Extract Base64-encoded image data and convert it
            QString base64Data = outputString.mid(11);
            QByteArray imageData = QByteArray::fromBase64(base64Data.toUtf8());
            QImage image = QImage::fromData(imageData);

            if (!image.isNull()) {
                mazeSolverLabel->setPixmap(QPixmap::fromImage(image).scaled(
                    mazeSolverLabel->size(), Qt::KeepAspectRatio, Qt::SmoothTransformation));
            }
        }
    }

private:
    QLabel *mazeSolverLabel;
    QProcess *process;
};

int main(int argc, char *argv[]) {
    QApplication app(argc, argv);
    MainWindow window;
    window.setWindowTitle("Maze Solver GUI");
    window.show();
    return app.exec();
}

#include "gui_launcher.moc"
