#include <gazebo_msgs/srv/spawn_entity.hpp>
#include <rclcpp/rclcpp.hpp>
#include <string>
#include <chrono>

using namespace std::chrono_literals;

class SpawnAssets : public rclcpp::Node {
public:
  SpawnAssets() : Node("spawn_assets") {
    spawn_client_ = this->create_client<gazebo_msgs::srv::SpawnEntity>(
        "/spawn_entity");
    while (!spawn_client_->wait_for_service(1s)) {
      if (!rclcpp::ok()) {
        RCLCPP_ERROR(this->get_logger(),
                     "Interrupted while waiting for the service. Exiting.");
        return;
      }
      RCLCPP_INFO(this->get_logger(),
                   "Waiting for spawn_entity service...");
    }

    spawn_table();
    spawn_whiteboard();
   
  }

private:
  rclcpp::Client<gazebo_msgs::srv::SpawnEntity>::SharedPtr spawn_client_;

  // Spawn the table model
  void spawn_table() {
    auto request = std::make_shared<gazebo_msgs::srv::SpawnEntity::Request>();
    request->name = "table";
    request->xml = R"(
      <sdf version="1.6">
        <model name="table">
          <static>true</static>
          <link name="link">
            <collision name="collision">
              <geometry>
                <mesh>
                  <uri>file:///home/nathan/ros2_ws/src/ur3_simulation/assets/Table.dae</uri>
                </mesh>
              </geometry>
            </collision>
            <visual name="visual">
              <geometry>
                <mesh>
                  <uri>file:///home/nathan/ros2_ws/src/ur3_simulation/assets/Table.dae</uri>
                </mesh>
              </geometry>
              <material>
                <script>
                  <uri>file:///home/nathan/ros2_ws/src/ur3_simulation/assets/gazebo.material</uri>
                  <name>Table Image/Image</name>
                </script>
              </material>
            </visual>
          </link>
        </model>
      </sdf>
    )";
    request->robot_namespace = "";
    request->initial_pose.position.x = 0.0;
    request->initial_pose.position.y = 0.0;
    request->initial_pose.position.z = 0.0;
    request->initial_pose.orientation.w = 1.0;

    auto result_future = spawn_client_->async_send_request(request);
    if (rclcpp::spin_until_future_complete(this->get_node_base_interface(),
                                           result_future) ==
        rclcpp::FutureReturnCode::SUCCESS) {
      auto result = result_future.get();
      if (result->success) {
        RCLCPP_INFO(this->get_logger(), "Table spawned successfully.");
      } else {
        RCLCPP_ERROR(this->get_logger(), "Failed to spawn table: %s",
                       result->status_message.c_str());
      }
    } else {
      RCLCPP_ERROR(this->get_logger(), "Failed to call spawn_entity service.");
    }
  }

  // Spawn the whiteboard model
  void spawn_whiteboard() {
    auto request = std::make_shared<gazebo_msgs::srv::SpawnEntity::Request>();
    request->name = "whiteboard";
    request->xml = R"(
      <sdf version="1.6">
        <model name="whiteboard">
          <static>true</static>
          <link name="link">
            <collision name="collision">
              <geometry>
                <mesh>
                  <uri>file:///home/nathan/ros2_ws/src/ur3_simulation/assets/whiteboard.dae</uri>
                </mesh>
              </geometry>
            </collision>
            <visual name="visual">
              <geometry>
                <mesh>
                  <uri>file:///home/nathan/ros2_ws/src/ur3_simulation/assets/whiteboard.dae</uri>
                </mesh>
              </geometry>
              <material>
                <script>
                  <uri>file:///home/nathan/ros2_ws/src/ur3_simulation/assets/gazebo.material</uri>
                  <name>Whiteboard/Image</name>
                </script>
              </material>
            </visual>
          </link>
        </model>
      </sdf>
    )";
    request->robot_namespace = "";
    request->initial_pose.position.x = 0.0;
    request->initial_pose.position.y = 0.0;
    request->initial_pose.position.z = 0.0;
    request->initial_pose.orientation.w = 1.0;

    auto result_future = spawn_client_->async_send_request(request);
    if (rclcpp::spin_until_future_complete(this->get_node_base_interface(),
                                           result_future) ==
        rclcpp::FutureReturnCode::SUCCESS) {
      auto result = result_future.get();
      if (result->success) {
        RCLCPP_INFO(this->get_logger(), "Whiteboard spawned successfully.");
      } else {
        RCLCPP_ERROR(this->get_logger(), "Failed to spawn whiteboard: %s",
                       result->status_message.c_str());
      }
    } else {
      RCLCPP_ERROR(this->get_logger(), "Failed to call spawn_entity service.");
    }
  }

};

int main(int argc, char **argv) {
  rclcpp::init(argc, argv);
  rclcpp::spin(std::make_shared<SpawnAssets>());
  rclcpp::shutdown();
  return 0;
}
