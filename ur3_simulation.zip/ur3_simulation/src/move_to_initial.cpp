#include <rclcpp/rclcpp.hpp>
#include <moveit/move_group_interface/move_group_interface.h>
#include <moveit/planning_scene_interface/planning_scene_interface.h>
#include <moveit/robot_model_loader/robot_model_loader.h>

int main(int argc, char** argv)
{
    rclcpp::init(argc, argv);
    auto node = rclcpp::Node::make_shared("ur3_move_to_pose");

    // Load the robot model to introspect planning groups
    robot_model_loader::RobotModelLoader robot_model_loader(node, "robot_description");
    moveit::core::RobotModelPtr kinematic_model = robot_model_loader.getModel();

    if (!kinematic_model)
    {
        RCLCPP_ERROR(node->get_logger(), "Failed to load robot model.");
        return 1;
    }

    // List available planning groups
    RCLCPP_INFO(node->get_logger(), "Available planning groups:");
    const auto& group_names = kinematic_model->getJointModelGroupNames();
    for (const auto& group : group_names)
    {
        RCLCPP_INFO(node->get_logger(), "  - %s", group.c_str());
    }

    // Use the correct group name for your robot
    const std::string group_name = "ur_manipulator";
    moveit::planning_interface::MoveGroupInterface move_group(node, group_name);

    // Define joint target positions (in radians)
    std::map<std::string, double> target_joint_positions;
    target_joint_positions["shoulder_pan_joint"] = 17.0 * M_PI / 180.0;
    target_joint_positions["shoulder_lift_joint"] = -88.0 * M_PI / 180.0;
    target_joint_positions["elbow_joint"] = -14.0 * M_PI / 180.0;
    target_joint_positions["wrist_1_joint"] = -152.0 * M_PI / 180.0;
    target_joint_positions["wrist_2_joint"] = 85.0 * M_PI / 180.0;
    target_joint_positions["wrist_3_joint"] = 17.0 * M_PI / 180.0;

    move_group.setJointValueTarget(target_joint_positions);

    // Plan and execute
    moveit::planning_interface::MoveGroupInterface::Plan plan;
    bool success = (move_group.plan(plan) == moveit::core::MoveItErrorCode::SUCCESS);

    if (success)
    {
        RCLCPP_INFO(node->get_logger(), "Plan successful. Executing...");
        move_group.execute(plan);
    }
    else
    {
        RCLCPP_ERROR(node->get_logger(), "Planning failed.");
    }

    rclcpp::shutdown();
    return 0;
}
